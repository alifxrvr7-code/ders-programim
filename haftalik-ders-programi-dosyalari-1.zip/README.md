# Haftalık Ders Programım

Tablet ve telefonda çalışan basit, Türkçe bir haftalık çalışma planlayıcısı.

## Özellikler
- Haftanın 7 günü için görev ekleme, düzenleme ve silme
- TYT / AYT seçimi, ders, konu, çalışma türü, saat ve süre
- Soru sayısı, kaynak, video bağlantısı ve notlar
- Görevleri tamamlandı olarak işaretleme
- JSON yedeği indirme ve yedekten geri yükleme
- Tarayıcıda yerel kayıt; harici sunucuya kişisel veri göndermez

## GitHub Pages ile yayınlama
1. GitHub'da yeni bir repository oluştur.
2. `index.html`, `manifest.json` ve `sw.js` dosyalarını repository ana dizinine yükle.
3. Repository > Settings > Pages bölümüne gir.
4. Build and deployment kısmında `Deploy from a branch` seç; branch olarak `main`, folder olarak `/(root)` seçip Save'e bas.
5. Birkaç dakika sonra Pages bölümünde görünen bağlantıyı aç.
6. Android Chrome menüsünden "Ana ekrana ekle" seçeneğini kullan.

Not: Bu bir web uygulamasıdır (PWA). APK değildir; ana ekrana eklenerek uygulama gibi açılabilir.
